"""Сборка .erf без изменения исходного вложения. Python 3 + lxml + v8unpack 1.2.15."""
from pathlib import Path
from copy import deepcopy
from uuid import UUID, uuid5
import json
import shutil
import struct
import subprocess
import sys
from lxml import etree as ET

ROOT = Path(__file__).resolve().parent
NS = {
    None: 'http://v8.1c.ru/8.1/data-composition-system/schema',
    'dcsset': 'http://v8.1c.ru/8.1/data-composition-system/settings',
    'dcscor': 'http://v8.1c.ru/8.1/data-composition-system/core',
    'v8': 'http://v8.1c.ru/8.1/data/core',
    'cfg': 'http://v8.1c.ru/8.1/data/enterprise/current-config',
    'xs': 'http://www.w3.org/2001/XMLSchema',
    'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
}
NAMESPACE = UUID('ef14c3cc-c7ca-45bf-8a6c-27763bf7d86e')
NAME = 'ПечатьНоменклатурыУТ115'
SCHEMA_NAME = 'ОсновнаяСхемаКомпоновкиДанных'
PARAMETERS = [
    ('ДатаОстатков', 'Дата остатков (пусто — сегодня)', 'xs:dateTime', '0001-01-01T00:00:00'),
    ('ГруппаНоменклатуры', 'Группы номенклатуры', 'cfg:CatalogRef.Номенклатура', None),
    ('Склады', 'Склады (пусто — все)', 'cfg:CatalogRef.Склады', None),
    ('СкладыПоИерархии', 'Включать подчинённые склады', 'xs:boolean', 'false'),
    ('СтрокаПоиска', 'Часть наименования', 'xs:string', ''),
    ('ВыводитьИзображения', 'Выводить изображения', 'xs:boolean', 'true'),
    ('ПроверкаСовместимости', 'Диагностика метаданных (без чтения остатков)', 'xs:boolean', 'false'),
]


def uid(key):
    return str(uuid5(NAMESPACE, key))


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def node(parent, name, text=None, prefix=None, **attrs):
    ns = NS[prefix]
    child = ET.SubElement(parent, '{' + ns + '}' + name, attrs)
    if text is not None:
        child.text = str(text)
    return child


def value(parent, name, kind, text):
    part = node(parent, name, prefix='dcscor')
    part.set('{' + NS['xsi'] + '}type', kind)
    if text is None:
        part.attrib.clear()
        part.set('{' + NS['xsi'] + '}nil', 'true')
    else:
        part.text = text
    return part


def make_schema():
    schema = ET.Element('{' + NS[None] + '}DataCompositionSchema', nsmap=NS)
    source = node(schema, 'dataSource')
    node(source, 'name', 'Источник')
    node(source, 'dataSourceType', 'Local')
    dataset = node(schema, 'dataSet')
    dataset.set('{' + NS['xsi'] + '}type', 'DataSetQuery')
    node(dataset, 'name', 'Служебный')
    field = node(dataset, 'field')
    field.set('{' + NS['xsi'] + '}type', 'DataSetFieldField')
    node(field, 'dataPath', 'СлужебноеПоле')
    node(field, 'field', 'СлужебноеПоле')
    node(dataset, 'dataSource', 'Источник')
    # Печатный результат формирует ПриКомпоновкеРезультата. Этот набор не
    # обращается к базе и нужен только для штатной формы/настроек внешнего отчёта.
    node(dataset, 'query', 'ВЫБРАТЬ 1 КАК СлужебноеПоле')
    for name, caption, kind, default in PARAMETERS:
        parameter = node(schema, 'parameter')
        node(parameter, 'name', name)
        title = node(parameter, 'title')
        title.set('{' + NS['xsi'] + '}type', 'v8:LocalStringType')
        item = node(title, 'item', prefix='v8')
        node(item, 'lang', 'ru', prefix='v8')
        node(item, 'content', caption, prefix='v8')
        types = node(parameter, 'valueType')
        node(types, 'Type', kind, prefix='v8')
        if kind == 'xs:dateTime':
            qualifiers = node(types, 'DateQualifiers', prefix='v8')
            node(qualifiers, 'DateFractions', 'Date', prefix='v8')
        default_node = node(parameter, 'value')
        if default is None:
            default_node.set('{' + NS['xsi'] + '}nil', 'true')
        else:
            default_node.set('{' + NS['xsi'] + '}type', kind)
            default_node.text = default
        node(parameter, 'useRestriction', 'false')
        if name in {'ГруппаНоменклатуры', 'Склады'}:
            node(parameter, 'valueListAllowed', 'true')
        node(parameter, 'use', 'Always')
    variant = node(schema, 'settingsVariant')
    node(variant, 'name', 'Основной', prefix='dcsset')
    presentation = node(variant, 'presentation', 'Печать номенклатуры', prefix='dcsset')
    presentation.set('{' + NS['xsi'] + '}type', 'xs:string')
    settings = node(variant, 'settings', prefix='dcsset')
    parameters = node(settings, 'dataParameters', prefix='dcsset')
    for name, _, kind, default in PARAMETERS:
        item = node(parameters, 'item', prefix='dcscor')
        item.set('{' + NS['xsi'] + '}type', 'dcsset:SettingsParameterValue')
        node(item, 'use', 'true', prefix='dcscor')
        node(item, 'parameter', name, prefix='dcscor')
        value(item, 'value', kind, default)
        node(item, 'userSettingID', uid('parameter.' + name), prefix='dcsset')
        node(item, 'viewMode', 'QuickAccess', prefix='dcsset')
    node(settings, 'outputParameters', prefix='dcsset')
    group = node(settings, 'item', prefix='dcsset')
    group.set('{' + NS['xsi'] + '}type', 'dcsset:StructureItemGroup')
    selection = node(group, 'selection', prefix='dcsset')
    item = node(selection, 'item', prefix='dcsset')
    item.set('{' + NS['xsi'] + '}type', 'dcsset:SelectedItemAuto')
    node(group, 'outputParameters', prefix='dcsset')
    return schema, settings


def xml_bytes(root):
    return b'\xef\xbb\xbf' + ET.tostring(root, encoding='utf-8', xml_declaration=True, pretty_print=True)


def schema_binary(schema, settings):
    wrapper = ET.Element('SchemaFile', nsmap={None: '', **{k: v for k, v in NS.items() if k}})
    inner = deepcopy(schema)
    inner.tag = '{' + NS[None] + '}dataCompositionSchema'
    wrapper.append(inner)
    # Отдельный XDTO-документ должен объявлять также префиксы, используемые
    # только в строковых QName (xsi:type="xs:dateTime" и т. п.). deepcopy
    # вложенного settings теряет такие объявления вместе с родителем schema.
    defaults = ET.Element('{' + NS['dcsset'] + '}Settings',
                          nsmap={None: NS['dcsset'], **{k: v for k, v in NS.items() if k}})
    defaults.attrib.update(settings.attrib)
    defaults.text = settings.text
    for child in settings:
        defaults.append(deepcopy(child))
    empty = ET.Element('SchemaFile', nsmap={None: '', **{k: v for k, v in NS.items() if k}})
    node(empty, 'dataCompositionSchema')
    first, second, third = xml_bytes(wrapper), xml_bytes(defaults), xml_bytes(empty)
    # Формат сохранённого макета СКД: версия, маркер, две длины UInt64 и три XML-блока.
    return struct.pack('<IIQQ', 0, 1, len(first), len(second)) + first + second + third


def build():
    source = ROOT / 'source'
    source.mkdir(exist_ok=True)
    original = json.loads((ROOT / 'original/ExternalDataProcessor.json').read_text())
    original['name'] = NAME
    original['name2'] = {'ru': 'Печать номенклатуры с изображениями (УТ 11.5)'}
    original['comment'] = 'Целевая конфигурация: УТ 11.5.27.107; требуется проверка в тестовой базе.'
    original['code_info_obj'] = [['3', '1', '0', '""', '0']]
    original['code_encoding_obj'] = 'utf-8-sig'
    main = original['header'][0][3][1]
    caption = main[1][3][1]
    caption[2] = '"' + NAME + '"'
    caption[3] = ['1', '"ru"', '"' + original['name2']['ru'] + '"']
    caption[4] = '"' + original['comment'] + '"'
    main[1][4] = '00000000-0000-0000-0000-000000000000'  # Без обычной формы УТ 10.3.
    main[1][5] = uid(SCHEMA_NAME)  # Основная схема СКД, штатная управляемая форма.
    main[3] = [main[3][0], '2', 'caad23a1-1c41-4c91-a59e-3fa4ed19182e', uid(SCHEMA_NAME)]
    main[4] = [main[4][0], '0']  # Все параметры задаются СКД по именам типов УТ 11.5.
    main[5] = [main[5][0], '0']
    original['copyinfo'] = [['4', ['2',
        ['caad23a1-1c41-4c91-a59e-3fa4ed19182e', 'caad23a1-1c41-4c91-a59e-3fa4ed19182e', '1',
         ['3daea016-69b7-4ed4-9453-127911372fe6', '"Макет"']],
        [uid(SCHEMA_NAME), uid(SCHEMA_NAME), '1',
         ['3daea016-69b7-4ed4-9453-127911372fe6', '"' + SCHEMA_NAME + '"']]],
        ['0'], ['0'], ['0', '0'], ['0']]]
    write_json(source / 'ExternalDataProcessor.json', original)
    text = (ROOT / 'src/МодульОтчета.bsl').read_text()
    text = text.replace('// {{ЛОГИКА_ПЕЧАТИ}}', (ROOT / 'src/ЛогикаПечати.bsl').read_text())
    (source / 'ExternalDataProcessor.obj.bsl').write_text(text, encoding='utf-8-sig')
    shutil.copytree(ROOT / 'original/Template/Макет', source / 'Template/Макет', dirs_exist_ok=True)
    schema_folder = source / 'Template' / SCHEMA_NAME
    template = json.loads((source / 'Template/Макет/Template.json').read_text())
    template['type'] = 'scheme'
    template['name'] = SCHEMA_NAME
    template['name2'] = {'ru': SCHEMA_NAME}
    # v8unpack сохраняет часть полей только в сыром заголовке: меняем обе формы.
    template['header'][0][1][1] = '6'
    template['header'][0][1][2][2] = '"' + SCHEMA_NAME + '"'
    template['header'][0][1][2][3] = ['1', '"ru"', '"' + SCHEMA_NAME + '"']
    write_json(schema_folder / 'Template.json', template)
    write_json(schema_folder / 'Template.id.json', {'uuid': uid(SCHEMA_NAME)})
    schema, settings = make_schema()
    (schema_folder / 'Template.bin').write_bytes(schema_binary(schema, settings))
    (ROOT / 'src/ОсновнаяСхемаКомпоновкиДанных.xml').write_bytes(xml_bytes(schema))
    output = ROOT / 'ПечатьНоменклатуры_УТ_11_5_27_107.erf'
    subprocess.run([sys.executable, '-m', 'v8unpack', '-B', str(source), str(output),
                    '--temp', '/tmp/ut115-build', '--processes', '2'], check=True)
    print(output)


if __name__ == '__main__':
    build()
