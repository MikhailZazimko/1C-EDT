from pathlib import Path
import hashlib
import json
import re
import struct
import unittest
from lxml import etree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'source'
ROUNDTRIP = ROOT / 'roundtrip'
SCHEMA = 'ОсновнаяСхемаКомпоновкиДанных'
NS = {'s': 'http://v8.1c.ru/8.1/data-composition-system/schema',
      'st': 'http://v8.1c.ru/8.1/data-composition-system/settings',
      'c': 'http://v8.1c.ru/8.1/data-composition-system/core',
      'v8': 'http://v8.1c.ru/8.1/data/core'}


class PackageTest(unittest.TestCase):
    def test_balance_query_uses_register_and_resources_from_user_diagnostic(self):
        fixture = json.loads((ROOT / 'tests/fixtures/ut_11_5_27_107_metadata.json').read_text())
        code = (SOURCE / 'ExternalDataProcessor.obj.bsl').read_text(encoding='utf-8-sig')
        descriptor = re.search(r'Функция ОписаниеРегистраОстатков\(\).*?КонецФункции', code, re.S).group()
        register = re.search(r'ИмяРегистра = "([^"]+)";', descriptor).group(1)
        self.assertNotIn(register, fixture['absent_accumulation_registers'])
        metadata = fixture['accumulation_registers'][register]
        resources = re.search(r'ИмяРегистра, "([^"]+)", "([^"]+)"\)', descriptor).groups()
        self.assertTrue(set(resources) <= set(metadata['resources']))
        self.assertEqual(resources, ('ВНаличии', 'РезервироватьНаСкладе'))
        query = re.search(r'ТекстЗапроса =\s*\n\s*"(.*?)";', code, re.S).group(1)
        for placeholder, value in [('%Регистр%', register), ('%Наличие%', resources[0]), ('%Резерв%', resources[1])]:
            query = query.replace(placeholder, value)
        self.assertIn('РегистрНакопления.ЗапасыИПотребности.Остатки(&Граница, %Условия%)', query)
        selected_resources = re.findall(r'СУММА\(Остатки\.([А-Яа-яЁё]+)Остаток\)', query)
        self.assertEqual(set(selected_resources), set(resources))
        self.assertTrue({'Номенклатура', 'Склад'} <= set(metadata['dimensions']))
        self.assertIn('Условия.Добавить("Склад ССЫЛКА Справочник.Склады")', code)

    def test_every_xdto_qname_has_a_namespace_in_each_serialized_document(self):
        raw = (ROUNDTRIP / 'Template' / SCHEMA / 'Template.bin').read_bytes()
        _, _, first, second = struct.unpack('<IIQQ', raw[:24])
        sections = [('schema', raw[24:24 + first]),
                    ('settings', raw[24 + first:24 + first + second]),
                    ('extra', raw[24 + first + second:])]
        xsi_type = '{http://www.w3.org/2001/XMLSchema-instance}type'
        expected_namespaces = {'xs': 'http://www.w3.org/2001/XMLSchema',
                               'cfg': 'http://v8.1c.ru/8.1/data/enterprise/current-config',
                               'v8': NS['v8'], 'dcsset': NS['st'], 'dcscor': NS['c']}
        for section, xml in sections:
            for node in ET.fromstring(xml).iter():
                values = [node.get(xsi_type)]
                if node.tag == '{' + NS['v8'] + '}Type':
                    values.append(node.text)
                for value in values:
                    if not value:
                        continue
                    prefix = value.split(':', 1)[0] if ':' in value else None
                    with self.subTest(section=section, line=node.sourceline, qname=value):
                        self.assertIn(prefix, node.nsmap, 'XDTO QName uses an undeclared prefix')
                        if prefix in expected_namespaces:
                            self.assertEqual(node.nsmap[prefix], expected_namespaces[prefix])

    def test_binary_contains_new_code_and_is_still_an_external_report(self):
        root = json.loads((ROUNDTRIP / 'ExternalDataProcessor.json').read_text())
        self.assertEqual(root['header'][0][3][0], 'e41aff26-25cf-4bb6-b6c1-3f478a75f374')
        self.assertEqual(root['name'], 'ПечатьНоменклатурыУТ115')
        text = (ROUNDTRIP / 'ExternalDataProcessor.obj.bsl').read_text(encoding='utf-8-sig')
        self.assertEqual(text, (SOURCE / 'ExternalDataProcessor.obj.bsl').read_text(encoding='utf-8-sig'))
        self.assertIn('Процедура ПриКомпоновкеРезультата(', text)
        self.assertIn('СтандартнаяОбработка = Ложь;', text)
        self.assertIn('Функция СведенияОВнешнейОбработке() Экспорт', text)
        self.assertIn((ROOT / 'src/ЛогикаПечати.bsl').read_text(), text)

    def test_legacy_forms_and_catalog_type_uuids_are_removed(self):
        root = json.loads((ROUNDTRIP / 'ExternalDataProcessor.json').read_text())
        main = root['header'][0][3][1]
        self.assertEqual(main[4][1], '0')
        self.assertEqual(main[5][1], '0')
        self.assertEqual(main[1][4], '00000000-0000-0000-0000-000000000000')
        self.assertFalse((ROUNDTRIP / 'ReportForm').exists())
        self.assertNotIn('4772b3b4-f4a3-49c0-a1a5-8cb5961511a3', json.dumps(root))

    def test_native_composition_schema_link_and_binary_sections(self):
        root = json.loads((ROUNDTRIP / 'ExternalDataProcessor.json').read_text())
        folder = ROUNDTRIP / 'Template' / SCHEMA
        schema_id = json.loads((folder / 'Template.id.json').read_text())['uuid']
        self.assertEqual(root['header'][0][3][1][1][5], schema_id)
        self.assertEqual(json.loads((folder / 'Template.json').read_text())['type'], 'scheme')
        raw = (folder / 'Template.bin').read_bytes()
        version, marker, first, second = struct.unpack('<IIQQ', raw[:24])
        self.assertEqual((version, marker), (0, 1))
        sections = [raw[24:24 + first], raw[24 + first:24 + first + second], raw[24 + first + second:]]
        parsed = [ET.fromstring(s) for s in sections]
        self.assertEqual(parsed[0].tag, 'SchemaFile')
        self.assertEqual(parsed[1].tag, '{' + NS['st'] + '}Settings')
        self.assertEqual(parsed[2].tag, 'SchemaFile')
        self.assertEqual(raw, (SOURCE / 'Template' / SCHEMA / 'Template.bin').read_bytes())

    def test_parameter_types_resolve_by_configuration_names_and_are_editable(self):
        schema = ET.parse(ROOT / 'src' / (SCHEMA + '.xml'))
        parameters = {n.findtext('s:name', namespaces=NS): n for n in schema.findall('s:parameter', NS)}
        self.assertEqual(set(parameters), {'ДатаОстатков', 'ГруппаНоменклатуры', 'Склады',
                                          'СкладыПоИерархии', 'СтрокаПоиска',
                                          'ВыводитьИзображения', 'ПроверкаСовместимости'})
        self.assertEqual(parameters['Склады'].findtext('s:valueType/v8:Type', namespaces=NS),
                         'cfg:CatalogRef.Склады')
        self.assertEqual(parameters['ГруппаНоменклатуры'].findtext('s:valueType/v8:Type', namespaces=NS),
                         'cfg:CatalogRef.Номенклатура')
        self.assertEqual(parameters['Склады'].findtext('s:valueListAllowed', namespaces=NS), 'true')
        settings = schema.findall('s:settingsVariant/st:settings/st:dataParameters/c:item', NS)
        self.assertEqual({n.findtext('c:parameter', namespaces=NS) for n in settings}, set(parameters))
        self.assertTrue(all(n.findtext('st:viewMode', namespaces=NS) == 'QuickAccess' for n in settings))

    def test_original_print_layout_is_byte_identical(self):
        original = ROOT / 'original/Template/Макет/Template.mxl'
        output = ROUNDTRIP / 'Template/Макет/Template.mxl'
        self.assertEqual(hashlib.sha256(original.read_bytes()).digest(), hashlib.sha256(output.read_bytes()).digest())

    def test_ut10_calls_are_replaced_and_reserves_are_not_silently_ignored(self):
        code = (SOURCE / 'ExternalDataProcessor.obj.bsl').read_text(encoding='utf-8-sig')
        for old_call in ['ТоварыВРезервеНаСкладах', 'БазоваяЕдиницаИзмерения',
                         '.Хранилище.Получить()', 'ЭлементыФормы.']:
            self.assertNotIn(old_call, code)
        self.assertIn('РаботаСФайлами.ДвоичныеДанныеФайла(Файл)', code)
        self.assertIn('Расчёт без учёта резервов не выполняется', code)
        self.assertIn('Новый Граница(КонецДня(ДатаОтчета), ВидГраницы.Включая)', code)
        self.assertIn('ДиагностикаМетаданных', code)
        self.assertNotIn('УстановитьПривилегированныйРежим', code)


if __name__ == '__main__':
    unittest.main()
